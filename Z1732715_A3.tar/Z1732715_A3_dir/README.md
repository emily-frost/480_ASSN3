# 480_ASSN3
Microshell simulation in C++

Make || behave as a pipe using system calls.

System calls used:
- pipe
- fork
- exec
- dup2
